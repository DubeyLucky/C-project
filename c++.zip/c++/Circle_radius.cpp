#include <iostream>
#include<cmath>
using namespace std;



int main(){

    float r;
    float A;

    cout<<"Enter the value of redius of circle to calculate the area"<<endl;
    cin>>r;
     
     A = 3.14*r*r;

     cout<<A;

}