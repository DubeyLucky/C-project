#include <iostream>

using namespace std;

class Car{

    public:
    string model;
    string color;
    int price;

    void speed(){
        cout<<"You are in top speed";
        
    }

    void light(){
        cout<<"Your light is on";
    }
};

int main(){
Car car1;

car1.model = "Top model";
car1.color = "White";
car1.price = 2200000;

car1.speed();
car1.light();

cout<<car1.model<<endl;
cout<<car1.color<<endl;
cout<<car1.price<<endl;
};