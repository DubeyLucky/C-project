#include <iostream>
using namespace std;

int main(){
    
    int num1;
    int num2;
    
    cout<<"Hi, Guys" << endl;
    cout<<"Enter two number";
    cin>> num1 >> num2;
    cout<<"Sum of number "<<num1 + num2<<endl;
    return 0;
}