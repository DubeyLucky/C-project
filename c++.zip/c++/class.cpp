#include <iostream>

using namespace std;

class Human{
    public :
    string name;
    string occu;
    int age;

    void eat(){
        cout<<"Eating";
        
    }

    void sleep(){
        cout<<"sleeping";
    }

};

int main(){

    Human human1;

    human1.name = "Arya";
    human1.occu = "KKKK" ;
    human1.age = 800;

    cout<<human1.name<<endl;
    cout<<human1.occu<<endl;
    cout<<human1.age<<endl;
}