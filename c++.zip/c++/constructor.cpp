#include <iostream>
using namespace std;


class Human{

    public:

    string name;
    int age;

    Human(string name, int age){
        this->name = name;
        this->age = age;
        
    }
};
int main(){

    Human human1("Ram",2222);

    cout<<human1.name<<endl;
    cout<<human1.age;
};