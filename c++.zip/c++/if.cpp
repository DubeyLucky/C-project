#include <iostream>
using namespace std;

int main(){
    
    int x;
    
    cout<<"Enter any number";
    cin>>x;
    
    if(x>0){
        cout<<"You have enterd positive number"<<x<<endl;
    }
    cout<<"Please try again later";
    return 0;
}