#include <iostream>
using namespace std;

int main(){
    
    int num;
    
    cout<<"Enter any number to check even/odd";
    cin>>num;
    
    if(num%2 == 0){
        cout<<"Even number";
    }else{
        cout<<"Odd number";
    }
    
   return 0;
}