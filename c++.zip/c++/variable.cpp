#include<iostream>
using namespace std;

int main(){

   int x;
   int y; 
   int sum;

   x = 10;
   y = 20;
   sum=x+y;


   cout<<sum;
   
}